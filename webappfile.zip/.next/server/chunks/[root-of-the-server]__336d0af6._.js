module.exports = {

"[project]/.next-internal/server/app/api/estimate/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/node:crypto [external] (node:crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}}),
"[externals]/node:os [external] (node:os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:os", () => require("node:os"));

module.exports = mod;
}}),
"[externals]/node:util [external] (node:util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:util", () => require("node:util"));

module.exports = mod;
}}),
"[externals]/node:process [external] (node:process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}}),
"[externals]/node:http [external] (node:http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:http", () => require("node:http"));

module.exports = mod;
}}),
"[externals]/node:https [external] (node:https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:https", () => require("node:https"));

module.exports = mod;
}}),
"[externals]/node:zlib [external] (node:zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:zlib", () => require("node:zlib"));

module.exports = mod;
}}),
"[externals]/node:stream [external] (node:stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/assert [external] (assert, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}}),
"[externals]/tty [external] (tty, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/constants [external] (constants, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("constants", () => require("constants"));

module.exports = mod;
}}),
"[project]/src/app/api/estimate/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$azure$2f$storage$2d$blob$2f$dist$2d$esm$2f$storage$2d$blob$2f$src$2f$BlobServiceClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@azure/storage-blob/dist-esm/storage-blob/src/BlobServiceClient.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/uuid/dist/esm/v4.js [app-route] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$azure$2f$cosmos$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@azure/cosmos/dist/esm/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$azure$2f$cosmos$2f$dist$2f$esm$2f$CosmosClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@azure/cosmos/dist/esm/CosmosClient.js [app-route] (ecmascript)");
;
;
;
;
async function POST(request) {
    try {
        // Debug: Log environment variables (remove in production)
        console.log("Environment check:");
        console.log("AZURE_STORAGE_CONNECTION_STRING:", process.env.AZURE_STORAGE_CONNECTION_STRING ? "SET" : "MISSING");
        console.log("AZURE_STORAGE_BLOB_CONTAINER_NAME:", process.env.AZURE_STORAGE_BLOB_CONTAINER_NAME ? "SET" : "MISSING");
        console.log("AI_ENDPOINT_URL:", process.env.AI_ENDPOINT_URL ? "SET" : "MISSING");
        console.log("AZURE_ML_API_KEY:", process.env.AZURE_ML_API_KEY ? "SET" : "MISSING");
        console.log("AZURE_COSMOS_CONNECTION_STRING:", process.env.AZURE_COSMOS_CONNECTION_STRING ? "SET" : "MISSING");
        // --- 1. PARSE FORM DATA (No changes) ---
        const formData = await request.formData();
        const file = formData.get('file-upload');
        const brand = formData.get('brand');
        const model = formData.get('model');
        const year = formData.get('year');
        const mileage = formData.get('mileage');
        const enpower = formData.get('enpower');
        const envolume = formData.get('envolume');
        const fuel_type = formData.get('fuel_type');
        const transmission = formData.get('transmission');
        if (!file) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "File is required."
            }, {
                status: 400
            });
        }
        // --- 2. UPLOAD IMAGE TO AZURE BLOB STORAGE (No changes) ---
        console.log("Step 2: Uploading to Azure Blob Storage...");
        const blobServiceClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$azure$2f$storage$2d$blob$2f$dist$2d$esm$2f$storage$2d$blob$2f$src$2f$BlobServiceClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BlobServiceClient"].fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);
        // ... (rest of blob logic is the same)
        const containerClient = blobServiceClient.getContainerClient(process.env.AZURE_STORAGE_BLOB_CONTAINER_NAME);
        const blobName = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}-${file.name}`;
        const blockBlobClient = containerClient.getBlockBlobClient(blobName);
        const buffer = Buffer.from(await file.arrayBuffer());
        await blockBlobClient.upload(buffer, buffer.length);
        const imageUrl = blockBlobClient.url;
        console.log("Step 2: Blob upload successful, URL:", imageUrl);
        // ==================================================================
        // --- 3. CALL REAL AZURE ML ENDPOINT ---
        // ==================================================================
        console.log("Step 3: Calling Azure ML endpoint...");
        const endpointUrl = process.env.AI_ENDPOINT_URL;
        const apiKey = process.env.AZURE_ML_API_KEY;
        if (!endpointUrl || !apiKey) {
            console.error("Azure ML credentials missing:", {
                endpointUrl: !!endpointUrl,
                apiKey: !!apiKey
            });
            throw new Error("Azure ML endpoint credentials are not configured.");
        }
        // Construct the request body exactly as the model schema requires.
        const requestBody = {
            input_data: {
                columns: [
                    "id",
                    "brand",
                    "model",
                    "mileage",
                    "year",
                    "enpower",
                    "envolume",
                    "fuel_type",
                    "transmission"
                ],
                data: [
                    [
                        0,
                        brand,
                        model,
                        parseInt(mileage),
                        parseInt(year),
                        parseInt(enpower),
                        parseInt(envolume),
                        fuel_type,
                        transmission
                    ]
                ]
            }
        };
        // Set up the required headers.
        const requestHeaders = new Headers({
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`,
            "azureml-model-deployment": "festivetechjob11-1"
        });
        console.log("Calling Azure ML endpoint with body:", JSON.stringify(requestBody, null, 2));
        const mlResponse = await fetch(endpointUrl, {
            method: "POST",
            body: JSON.stringify(requestBody),
            headers: requestHeaders
        });
        if (!mlResponse.ok) {
            const errorBody = await mlResponse.text();
            console.error("Azure ML request failed:", mlResponse.status, mlResponse.statusText, errorBody);
            throw new Error(`Request to AI model failed with status ${mlResponse.status}: ${errorBody}`);
        }
        const predictionResult = await mlResponse.json();
        console.log("Received prediction from Azure ML:", predictionResult);
        console.log("Step 3: ML prediction successful");
        // IMPORTANT: Adjust this line based on the actual JSON output of your model.
        // It's often an array with a single prediction.
        const estimatedPrice = Math.round(predictionResult[0]);
        // ==================================================================
        // --- 4. SAVE TO COSMOS DB (No changes) ---
        console.log("Step 4: Saving to Cosmos DB...");
        const cosmosClient = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$azure$2f$cosmos$2f$dist$2f$esm$2f$CosmosClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CosmosClient"](process.env.AZURE_COSMOS_CONNECTION_STRING);
        // ... (rest of cosmos db logic is the same)
        const database = cosmosClient.database(process.env.AZURE_COSMOS_DATABASE_NAME);
        const container = database.container(process.env.AZURE_COSMOS_CONTAINER_NAME);
        const carData = {
            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(),
            brand,
            model,
            fuel_type,
            transmission,
            enpower: parseInt(enpower),
            envolume: parseInt(envolume),
            year: parseInt(year),
            mileage: parseInt(mileage),
            estimatedPrice,
            imageUrl,
            createdAt: new Date().toISOString()
        };
        await container.items.create(carData);
        console.log(`Step 4: Successfully saved car data with REAL price to Cosmos DB.`);
        // --- 5. RETURN SUCCESS RESPONSE (No changes) ---
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            message: "Estimation successful!",
            data: carData
        }, {
            status: 200
        });
    } catch (error) {
        console.error("Error in estimation process:", error);
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Failed to process estimation.",
            details: errorMessage
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__336d0af6._.js.map