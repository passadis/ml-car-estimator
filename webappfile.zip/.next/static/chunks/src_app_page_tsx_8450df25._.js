(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_90e82138._.js",
  "static/chunks/node_modules_cf1d56ec._.js"
],
    source: "dynamic"
});
